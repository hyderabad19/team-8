<?php



?>
<html>
    <form name="form1" action="addingnewcluster.php" method="post">
        <input type="text" name="addnewcluster"/>
        <input type="submit" value="Add new">
        </form>
</html>